import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image
import cv2
import numpy as np
import webbrowser
from collections import deque

# Atur tema default
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class ImageProcessingApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # ========================= KONFIGURASI WINDOW UTAMA ========================= #
        self.title("🖼️ Digital Image Processing Studio (Interactive Panel)")
        self.geometry("1500x850")
        self.minsize(1300, 700)

        # Inisialisasi variabel
        self.original_image = None
        self.processed_image = None
        self.temp_image_for_preview = None # Untuk preview slider
        self.filename = ""
        self.IMAGE_WIDTH = 600
        self.IMAGE_HEIGHT = 450
        
        self.history = deque(maxlen=20)
        self.redo_stack = deque(maxlen=20)

        self.create_menubar()

        # ========================= LAYOUT UTAMA ========================= #
        self.grid_columnconfigure(0, weight=1, minsize=350) # Panel Kontrol Kiri
        self.grid_columnconfigure(1, weight=3) # Area Gambar Kanan
        self.grid_rowconfigure(0, weight=1)

        # ========================= FRAME KONTROL (KIRI) ========================= #
        control_frame = ctk.CTkFrame(self, width=350, corner_radius=15)
        control_frame.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")
        control_frame.grid_propagate(False)

        app_title = ctk.CTkLabel(control_frame, text="Kontrol Gambar", font=ctk.CTkFont(size=30, weight="bold"))
        app_title.pack(pady=(20, 10))
        
        static_controls_frame = ctk.CTkFrame(control_frame, fg_color="transparent")
        static_controls_frame.pack(pady=10, fill="x", padx=20)
        static_controls_frame.grid_columnconfigure((0,1), weight=1)

        ctk.CTkButton(static_controls_frame, text="📂 Buka Gambar", command=self.browse_files).grid(row=0, column=0, columnspan=2, padx=5, pady=5, sticky="ew")
        ctk.CTkButton(static_controls_frame, text="💾 Simpan Hasil", command=self.save_image).grid(row=1, column=0, columnspan=2, padx=5, pady=5, sticky="ew")
        self.undo_button = ctk.CTkButton(static_controls_frame, text="↩️ Undo", command=self.undo_action, state="disabled")
        self.undo_button.grid(row=2, column=0, padx=5, pady=10, sticky="ew")
        self.redo_button = ctk.CTkButton(static_controls_frame, text="↪️ Redo", command=self.redo_action, state="disabled")
        self.redo_button.grid(row=2, column=1, padx=5, pady=10, sticky="ew")
        self.reset_button = ctk.CTkButton(static_controls_frame, text="🔄 Reset Semua", command=self.reset_image, fg_color="#D35B58", hover_color="#C77C78", state="disabled")
        self.reset_button.grid(row=3, column=0, columnspan=2, padx=5, pady=5, sticky="ew")
        
        self.dynamic_controls_frame = ctk.CTkScrollableFrame(control_frame, label_text="Panel Operasi")
        self.dynamic_controls_frame.pack(pady=10, padx=20, fill="both", expand=True)

        exit_button = ctk.CTkButton(control_frame, text="Keluar", command=self.quit, fg_color="#e53e3e", hover_color="#c53030")
        exit_button.pack(side="bottom", fill="x", padx=20, pady=20)

        # ========================= FRAME GAMBAR (KANAN) ========================= #
        image_display_frame = ctk.CTkFrame(self, fg_color="transparent")
        image_display_frame.grid(row=0, column=1, padx=20, pady=20, sticky="nsew")
        image_display_frame.grid_columnconfigure((0, 1), weight=1)
        image_display_frame.grid_rowconfigure(1, weight=1)

        ctk.CTkLabel(image_display_frame, text="Gambar Original", font=ctk.CTkFont(size=20, weight="bold")).grid(row=0, column=0, pady=10)
        ctk.CTkLabel(image_display_frame, text="Gambar Hasil Proses", font=ctk.CTkFont(size=20, weight="bold")).grid(row=0, column=1, pady=10)

        self.original_image_label = ctk.CTkLabel(image_display_frame, text="Buka gambar untuk memulai...", corner_radius=10, fg_color="#2b2b2b")
        self.original_image_label.grid(row=1, column=0, padx=10, pady=10, sticky="nsew")
        
        self.processed_image_label = ctk.CTkLabel(image_display_frame, text="Hasil proses akan muncul di sini", corner_radius=10, fg_color="#2b2b2b")
        self.processed_image_label.grid(row=1, column=1, padx=10, pady=10, sticky="nsew")
    
    def create_menubar(self):
        menubar = tk.Menu(self)
        self.config(menu=menubar)
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Open...", command=self.browse_files)
        file_menu.add_command(label="Save As...", command=self.save_image)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.quit)
        edge_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Edge Detection", menu=edge_menu)
        first_grad_menu = tk.Menu(edge_menu, tearoff=0)
        edge_menu.add_cascade(label="1st Differential Gradient", menu=first_grad_menu)
        first_grad_menu.add_command(label="Sobel", command=self.apply_sobel)
        first_grad_menu.add_command(label="Prewitt", command=self.apply_prewitt)
        first_grad_menu.add_command(label="Robert", command=self.apply_robert)
        second_grad_menu = tk.Menu(edge_menu, tearoff=0)
        edge_menu.add_cascade(label="2nd Differential Gradient", menu=second_grad_menu)
        second_grad_menu.add_command(label="Laplacian", command=self.apply_laplacian)
        second_grad_menu.add_command(label="Laplacian of Gaussian (LoG)", command=self.apply_log)
        second_grad_menu.add_command(label="Canny", command=self.apply_canny)
        basic_ops_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Basic Ops", menu=basic_ops_menu)
        basic_ops_menu.add_command(label="Negative", command=self.apply_negative)
        arithmetics_menu = tk.Menu(basic_ops_menu, tearoff=0)
        basic_ops_menu.add_cascade(label="Arithmetics", menu=arithmetics_menu)
        arithmetics_menu.add_command(label="Add (+)", command=self.apply_add)
        arithmetics_menu.add_command(label="Subtract (-)", command=self.apply_subtract)
        boolean_menu = tk.Menu(basic_ops_menu, tearoff=0)
        basic_ops_menu.add_cascade(label="Boolean", menu=boolean_menu)
        boolean_menu.add_command(label="AND", command=self.apply_and)
        boolean_menu.add_command(label="OR", command=self.apply_or)
        boolean_menu.add_command(label="XOR", command=self.apply_xor)
        geometrics_menu = tk.Menu(basic_ops_menu, tearoff=0)
        basic_ops_menu.add_cascade(label="Geometrics", menu=geometrics_menu)
        geometrics_menu.add_command(label="Translation", command=self.setup_translation_controls)
        geometrics_menu.add_command(label="Rotation", command=self.setup_rotation_controls)
        geometrics_menu.add_command(label="Zooming", command=self.setup_zoom_controls)
        geometrics_menu.add_command(label="Flipping", command=self.apply_flipping)
        basic_ops_menu.add_command(label="Thresholding", command=self.setup_thresholding_controls)
        colouring_menu = tk.Menu(basic_ops_menu, tearoff=0)
        basic_ops_menu.add_cascade(label="Colouring", menu=colouring_menu)
        colouring_menu.add_command(label="Grayscale", command=self.apply_grayscale)
        colouring_menu.add_command(label="HSV", command=lambda: self.apply_colorspace(cv2.COLOR_BGR2HSV))
        colouring_menu.add_command(label="YUV", command=lambda: self.apply_colorspace(cv2.COLOR_BGR2YUV))
        enhancement_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Enhancement", menu=enhancement_menu)
        enhancement_menu.add_command(label="Brightness & Contrast", command=self.setup_brightness_contrast_controls)
        enhancement_menu.add_command(label="Histogram Equalization", command=self.apply_hist_equalization)
        smoothing_menu = tk.Menu(enhancement_menu, tearoff=0)
        enhancement_menu.add_cascade(label="Smoothing", menu=smoothing_menu)
        smoothing_menu.add_command(label="Lowpass (Blur)", command=self.apply_blur)
        smoothing_menu.add_command(label="Median Filtering", command=self.apply_median_filter)
        sharpening_menu = tk.Menu(enhancement_menu, tearoff=0)
        enhancement_menu.add_cascade(label="Sharpening", menu=sharpening_menu)
        sharpening_menu.add_command(label="Highpass Filter", command=self.apply_sharpen)
        sharpening_menu.add_command(label="Highboost Filtering", command=self.setup_highboost_controls)
        noise_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Noise", menu=noise_menu)
        noise_menu.add_command(label="Add Gaussian Noise", command=self.add_gaussian_noise)
        noise_menu.add_command(label="Add Impulse Noise (Salt & Pepper)", command=self.add_impulse_noise)
        about_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="About", menu=about_menu)
        about_menu.add_command(label="Info Tim Developer", command=self.show_dev_info)
        
    # ========================= KONTROL DINAMIS ========================= #
    def clear_dynamic_controls(self):
        for widget in self.dynamic_controls_frame.winfo_children():
            widget.destroy()
        self.temp_image_for_preview = None

    def _create_slider_set(self, parent, label_text, from_, to, initial_val, format_str, callback):
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        label = ctk.CTkLabel(frame, text=label_text, width=80)
        label.pack(side="left", padx=(0, 10))
        value_label = ctk.CTkLabel(frame, text=format_str.format(initial_val), width=50)
        value_label.pack(side="right", padx=(10, 0))
        slider = ctk.CTkSlider(frame, from_=from_, to=to, command=lambda val: callback(val, value_label, format_str))
        slider.set(initial_val)
        slider.pack(side="left", fill="x", expand=True)
        return frame, slider

    def setup_brightness_contrast_controls(self):
        if self.processed_image is None: return
        self.clear_dynamic_controls()
        self.temp_image_for_preview = self.processed_image.copy()
        bf, self.brightness_slider = self._create_slider_set(self.dynamic_controls_frame, "Brightness", -100, 100, 0, "{:.0f}", self.preview_brightness_contrast)
        bf.pack(fill="x", padx=10, pady=5)
        cf, self.contrast_slider = self._create_slider_set(self.dynamic_controls_frame, "Contrast", 0, 3, 1, "{:.2f}", self.preview_brightness_contrast)
        cf.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(self.dynamic_controls_frame, text="Apply", command=self.commit_brightness_contrast).pack(fill="x", padx=10, pady=10)

    def setup_rotation_controls(self):
        if self.processed_image is None: return
        self.clear_dynamic_controls()
        self.temp_image_for_preview = self.processed_image.copy()
        rf, self.rotation_slider = self._create_slider_set(self.dynamic_controls_frame, "Angle", 0, 360, 0, "{:.0f}°", self.preview_rotation)
        rf.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(self.dynamic_controls_frame, text="Apply", command=self.commit_rotation).pack(fill="x", padx=10, pady=10)

    def setup_thresholding_controls(self):
        if self.processed_image is None: return
        self.clear_dynamic_controls()
        self.temp_image_for_preview = self.processed_image.copy()
        tf, self.threshold_slider = self._create_slider_set(self.dynamic_controls_frame, "Threshold", 0, 255, 127, "{:.0f}", self.preview_thresholding)
        tf.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(self.dynamic_controls_frame, text="Apply", command=self.commit_thresholding).pack(fill="x", padx=10, pady=10)

    def setup_translation_controls(self):
        if self.processed_image is None: return
        self.clear_dynamic_controls()
        self.temp_image_for_preview = self.processed_image.copy()
        tx_f, self.tx_slider = self._create_slider_set(self.dynamic_controls_frame, "Translate X", -100, 100, 0, "{:.0f}px", self.preview_translation)
        tx_f.pack(fill="x", padx=10, pady=5)
        ty_f, self.ty_slider = self._create_slider_set(self.dynamic_controls_frame, "Translate Y", -100, 100, 0, "{:.0f}px", self.preview_translation)
        ty_f.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(self.dynamic_controls_frame, text="Apply", command=self.commit_translation).pack(fill="x", padx=10, pady=10)

    def setup_zoom_controls(self):
        if self.processed_image is None: return
        self.clear_dynamic_controls()
        self.temp_image_for_preview = self.processed_image.copy()
        fx_f, self.fx_slider = self._create_slider_set(self.dynamic_controls_frame, "Zoom X", 0.1, 3, 1, "{:.2f}x", self.preview_zoom)
        fx_f.pack(fill="x", padx=10, pady=5)
        fy_f, self.fy_slider = self._create_slider_set(self.dynamic_controls_frame, "Zoom Y", 0.1, 3, 1, "{:.2f}x", self.preview_zoom)
        fy_f.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(self.dynamic_controls_frame, text="Apply", command=self.commit_zoom).pack(fill="x", padx=10, pady=10)

    def setup_highboost_controls(self):
        if self.processed_image is None: return
        self.clear_dynamic_controls()
        self.temp_image_for_preview = self.processed_image.copy()
        k_f, self.k_slider = self._create_slider_set(self.dynamic_controls_frame, "K-Factor", 0, 5, 1.2, "{:.2f}", self.preview_highboost)
        k_f.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(self.dynamic_controls_frame, text="Apply", command=self.commit_highboost).pack(fill="x", padx=10, pady=10)

    # ========================= LOGIKA PREVIEW & COMMIT ========================= #
    def preview_brightness_contrast(self, _, __=None, ___=None):
        if self.temp_image_for_preview is None: return
        b_val, c_val = self.brightness_slider.get(), self.contrast_slider.get()
        self.brightness_slider.master.winfo_children()[1].configure(text=f"{b_val:.0f}")
        self.contrast_slider.master.winfo_children()[1].configure(text=f"{c_val:.2f}")
        preview = cv2.convertScaleAbs(self.temp_image_for_preview, alpha=c_val, beta=b_val)
        self.display_image(preview, self.processed_image_label)
    
    def commit_brightness_contrast(self):
        alpha, beta = self.contrast_slider.get(), self.brightness_slider.get()
        self.apply_filter(lambda img: cv2.convertScaleAbs(img, alpha=alpha, beta=beta))
        self.clear_dynamic_controls()

    def preview_rotation(self, value, value_label, format_str):
        if self.temp_image_for_preview is None: return
        value_label.configure(text=format_str.format(value))
        h, w = self.temp_image_for_preview.shape[:2]
        center, M = (w // 2, h // 2), cv2.getRotationMatrix2D((w // 2, h // 2), value, 1.0)
        preview = cv2.warpAffine(self.temp_image_for_preview, M, (w, h))
        self.display_image(preview, self.processed_image_label)

    def commit_rotation(self):
        angle = self.rotation_slider.get()
        h, w = self.processed_image.shape[:2]
        M = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
        self.apply_filter(lambda img: cv2.warpAffine(img, M, (w, h)))
        self.clear_dynamic_controls()
    
    def preview_thresholding(self, value, value_label, format_str):
        if self.temp_image_for_preview is None: return
        value_label.configure(text=format_str.format(value))
        gray = cv2.cvtColor(self.temp_image_for_preview, cv2.COLOR_BGR2GRAY) if len(self.temp_image_for_preview.shape) == 3 else self.temp_image_for_preview
        _, preview = cv2.threshold(gray, value, 255, cv2.THRESH_BINARY)
        self.display_image(preview, self.processed_image_label)

    def commit_thresholding(self):
        val = self.threshold_slider.get()
        def threshold_func(img):
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if len(img.shape) == 3 else img
            return cv2.threshold(gray, val, 255, cv2.THRESH_BINARY)[1]
        self.apply_filter(threshold_func)
        self.clear_dynamic_controls()
        
    def preview_translation(self, _, __=None, ___=None):
        if self.temp_image_for_preview is None: return
        tx, ty = self.tx_slider.get(), self.ty_slider.get()
        self.tx_slider.master.winfo_children()[1].configure(text=f"{tx:.0f}px")
        self.ty_slider.master.winfo_children()[1].configure(text=f"{ty:.0f}px")
        M = np.float32([[1, 0, tx], [0, 1, ty]])
        preview = cv2.warpAffine(self.temp_image_for_preview, M, (self.temp_image_for_preview.shape[1], self.temp_image_for_preview.shape[0]))
        self.display_image(preview, self.processed_image_label)

    def commit_translation(self):
        tx, ty = self.tx_slider.get(), self.ty_slider.get()
        M = np.float32([[1, 0, tx], [0, 1, ty]])
        self.apply_filter(lambda img: cv2.warpAffine(img, M, (img.shape[1], img.shape[0])))
        self.clear_dynamic_controls()

    def preview_zoom(self, _, __=None, ___=None):
        if self.temp_image_for_preview is None: return
        fx, fy = self.fx_slider.get(), self.fy_slider.get()
        self.fx_slider.master.winfo_children()[1].configure(text=f"{fx:.2f}x")
        self.fy_slider.master.winfo_children()[1].configure(text=f"{fy:.2f}x")
        preview = cv2.resize(self.temp_image_for_preview, None, fx=fx, fy=fy, interpolation=cv2.INTER_LINEAR)
        self.display_image(preview, self.processed_image_label)

    def commit_zoom(self):
        fx, fy = self.fx_slider.get(), self.fy_slider.get()
        self.apply_filter(lambda img: cv2.resize(img, None, fx=fx, fy=fy, interpolation=cv2.INTER_LINEAR))
        self.clear_dynamic_controls()

    def preview_highboost(self, value, value_label, format_str):
        if self.temp_image_for_preview is None: return
        value_label.configure(text=format_str.format(value))
        preview = cv2.addWeighted(self.temp_image_for_preview, 1 + value, cv2.GaussianBlur(self.temp_image_for_preview, (7, 7), 0), -value, 0)
        self.display_image(preview, self.processed_image_label)

    def commit_highboost(self):
        k = self.k_slider.get()
        self.apply_filter(lambda img: cv2.addWeighted(img, 1 + k, cv2.GaussianBlur(img, (7, 7), 0), -k, 0))
        self.clear_dynamic_controls()

    # ========================= FUNGSI UTAMA (IO, History, dll) ========================= #
    def browse_files(self):
        filename = filedialog.askopenfilename(title="Pilih sebuah gambar", filetypes=(("Image files", "*.jpg *.jpeg *.png"), ("All files", "*.*")))
        if filename:
            self.filename = filename
            self.load_and_display_image()
            
    def load_and_display_image(self):
        try:
            self.original_image = cv2.imread(self.filename)
            if self.original_image is None: raise ValueError("File tidak bisa dibaca.")
            self.history.clear()
            self.redo_stack.clear()
            self.display_image(self.original_image, self.original_image_label)
            self.reset_image()
        except Exception as e:
            messagebox.showerror("Error", f"Gagal memuat gambar: {e}")
            
    def display_image(self, cv2_image, label_widget):
        h, w = cv2_image.shape[:2]
        aspect_ratio = w / h
        if w > self.IMAGE_WIDTH or h > self.IMAGE_HEIGHT:
            if aspect_ratio > 1: new_w, new_h = self.IMAGE_WIDTH, int(self.IMAGE_WIDTH / aspect_ratio)
            else: new_w, new_h = int(self.IMAGE_HEIGHT * aspect_ratio), self.IMAGE_HEIGHT
        else: new_w, new_h = w, h
        
        resized = cv2.resize(cv2_image, (new_w, new_h), interpolation=cv2.INTER_AREA)
        if len(resized.shape) == 2:
            img_rgb = cv2.cvtColor(resized, cv2.COLOR_GRAY2RGB)
        else:
            img_rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)

        pil_img = Image.fromarray(img_rgb)
        ctk_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(new_w, new_h))
        
        label_widget.configure(image=ctk_img, text="")
        label_widget.image = ctk_img
        
    def apply_filter(self, filter_func, *args):
        if self.processed_image is None:
            messagebox.showwarning("Peringatan", "Buka gambar terlebih dahulu!")
            return
        try:
            self.history.append(self.processed_image.copy())
            self.processed_image = filter_func(self.processed_image.copy(), *args)
            self.display_image(self.processed_image, self.processed_image_label)
            self.redo_stack.clear()
            self.update_button_states()
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan saat menerapkan filter: {e}")
            if self.history: self.processed_image = self.history.pop()
            
    def update_button_states(self):
        self.undo_button.configure(state="normal" if self.history else "disabled")
        self.redo_button.configure(state="normal" if self.redo_stack else "disabled")
        self.reset_button.configure(state="normal" if self.original_image is not None else "disabled")
        
    def undo_action(self):
        if self.history:
            self.redo_stack.append(self.processed_image.copy())
            self.processed_image = self.history.pop()
            self.display_image(self.processed_image, self.processed_image_label)
            self.update_button_states()
            self.clear_dynamic_controls()
            
    def redo_action(self):
        if self.redo_stack:
            self.history.append(self.processed_image.copy())
            self.processed_image = self.redo_stack.pop()
            self.display_image(self.processed_image, self.processed_image_label)
            self.update_button_states()
            self.clear_dynamic_controls()
            
    def reset_image(self):
        if self.original_image is not None:
            self.history.clear()
            self.redo_stack.clear()
            self.processed_image = self.original_image.copy()
            self.display_image(self.processed_image, self.processed_image_label)
            self.update_button_states()
            self.clear_dynamic_controls()
            
    def save_image(self):
        if self.processed_image is None: return
        path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg")])
        if path:
            cv2.imwrite(path, self.processed_image)
            messagebox.showinfo("Sukses", f"Gambar disimpan di:\n{path}")
            
    def show_dev_info(self):
        messagebox.showinfo("Developer Info", "Aplikasi ini dikembangkan oleh:\n- Anda dan Tim Anda")
        
    # ========================= FUNGSI PEMROSESAN GAMBAR (TETAP SAMA) ========================= #
    def _get_second_image(self):
        messagebox.showinfo("Informasi", "Operasi ini membutuhkan gambar kedua.")
        filename = filedialog.askopenfilename(title="Pilih Gambar Kedua")
        if filename:
            img = cv2.imread(filename)
            if img is not None:
                h, w = self.processed_image.shape[:2]
                return cv2.resize(img, (w, h))
        return None
        
    def apply_sobel(self): self.apply_filter(lambda img: cv2.convertScaleAbs(cv2.Sobel(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), cv2.CV_64F, 1, 1, ksize=5)))
    def apply_laplacian(self): self.apply_filter(lambda img: cv2.convertScaleAbs(cv2.Laplacian(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), cv2.CV_64F)))
    def apply_canny(self): self.apply_filter(lambda img: cv2.Canny(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), 100, 200))
    def apply_log(self): self.apply_filter(lambda img: cv2.convertScaleAbs(cv2.Laplacian(cv2.GaussianBlur(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), (3, 3), 0), cv2.CV_64F)))
    def apply_prewitt(self):
        kernelx, kernely = np.array([[1,1,1],[0,0,0],[-1,-1,-1]]), np.array([[-1,0,1],[-1,0,1],[-1,0,1]])
        self.apply_filter(lambda img: cv2.add(cv2.filter2D(img, -1, kernelx), cv2.filter2D(img, -1, kernely)))
    def apply_robert(self):
        kernelx, kernely = np.array([[1, 0], [0, -1]]), np.array([[0, 1], [-1, 0]])
        self.apply_filter(lambda img: cv2.add(cv2.filter2D(img, -1, kernelx), cv2.filter2D(img, -1, kernely)))
    def apply_negative(self): self.apply_filter(lambda img: cv2.bitwise_not(img))
    def apply_grayscale(self): 
        self.apply_filter(lambda img: cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if len(img.shape) == 3 else img)
    def apply_colorspace(self, colorspace_code): self.apply_filter(lambda img: cv2.cvtColor(img, colorspace_code))
    def apply_add(self):
        img2 = self._get_second_image()
        if img2 is not None: self.apply_filter(lambda img1: cv2.add(img1, img2))
    def apply_subtract(self):
        img2 = self._get_second_image()
        if img2 is not None: self.apply_filter(lambda img1: cv2.subtract(img1, img2))
    def apply_and(self):
        img2 = self._get_second_image()
        if img2 is not None: self.apply_filter(lambda img1: cv2.bitwise_and(img1, img2))
    def apply_or(self):
        img2 = self._get_second_image()
        if img2 is not None: self.apply_filter(lambda img1: cv2.bitwise_or(img1, img2))
    def apply_xor(self):
        img2 = self._get_second_image()
        if img2 is not None: self.apply_filter(lambda img1: cv2.bitwise_xor(img1, img2))
    def apply_flipping(self): self.apply_filter(lambda img: cv2.flip(img, 1))
    def apply_hist_equalization(self):
        def equalize(img):
            if len(img.shape) == 3:
                img_ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
                img_ycrcb[:, :, 0] = cv2.equalizeHist(img_ycrcb[:, :, 0])
                return cv2.cvtColor(img_ycrcb, cv2.COLOR_YCrCb2BGR)
            else: return cv2.equalizeHist(img)
        self.apply_filter(equalize)
    def apply_blur(self): self.apply_filter(lambda img: cv2.blur(img, (7, 7)))
    def apply_median_filter(self): self.apply_filter(lambda img: cv2.medianBlur(img, 5))
    def apply_sharpen(self):
        kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
        self.apply_filter(lambda img: cv2.filter2D(img, -1, kernel))
    def add_gaussian_noise(self):
        self.apply_filter(lambda img: cv2.add(img, np.random.normal(0, 1, img.shape).astype('uint8') * 50))
    def add_impulse_noise(self):
        self.apply_filter(lambda img: cv2.randu(np.copy(img), 0, 255))

if __name__ == "__main__":
    app = ImageProcessingApp()
    app.mainloop()